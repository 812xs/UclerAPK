package com.ortakalan.kopru

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.TreeMap
import java.util.zip.ZipFile

class Link(val label: String, val target: String)

class Row(val number: Int, val cells: List<String>, val links: List<Link>) {

    val text: String by lazy {
        val sb = StringBuilder()
        for (c in cells) {
            if (c.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append("  •  ")
            sb.append(c)
        }
        sb.toString()
    }

    val searchKey: String by lazy { text.lowercase(TR) }

    companion object {
        val TR: Locale = Locale("tr", "TR")
    }
}

class SheetInfo(val name: String, val path: String)

/**
 * .xlsx dosyasını doğrudan ZIP + XML olarak okur (Apache POI kullanmaz, 10 bin+ satırda hızlıdır).
 * Köprüleri iki yerden toplar:
 *  1) <hyperlinks> bölümü (hücreye eklenmiş köprüler)
 *  2) =HYPERLINK("yol";"metin") formülleri
 * Köprü adresi hiçbir şekilde değiştirilmez.
 */
object XlsxReader {

    private val HYPERLINK_RE = Regex(
        "HYPERLINK\\s*\\(\\s*\"((?:[^\"]|\"\")*)\"",
        RegexOption.IGNORE_CASE
    )

    // ---------------------------------------------------------------- sayfa listesi

    fun listSheets(file: File): List<SheetInfo> {
        return ZipFile(file).use { zip ->
            val p = open(zip, "xl/workbook.xml")
                ?: throw IllegalArgumentException(
                    "Bu dosya .xlsx biçiminde değil. Excel'de \"Farklı Kaydet\" ile .xlsx olarak kaydedip tekrar deneyin."
                )
            val rels = readRels(zip, "xl/_rels/workbook.xml.rels")
            val result = ArrayList<SheetInfo>()
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && ln(p) == "sheet") {
                    val name = attr(p, "name") ?: "Sayfa"
                    val rid = attrSuffix(p, "id")
                    val target = if (rid != null) rels[rid] else null
                    if (target != null) {
                        val path = if (target.startsWith("/")) target.substring(1) else "xl/$target"
                        result.add(SheetInfo(name, path))
                    }
                }
                ev = p.next()
            }
            if (result.isEmpty()) throw IllegalArgumentException("Dosyada okunabilir sayfa bulunamadı.")
            result
        }
    }

    // ---------------------------------------------------------------- sayfa içeriği

    fun readSheet(file: File, info: SheetInfo): List<Row> {
        return ZipFile(file).use { zip ->
            val shared = readShared(zip)
            val dateXf = readDateStyles(zip)

            val slash = info.path.lastIndexOf('/')
            val dir = info.path.substring(0, slash + 1)
            val fname = info.path.substring(slash + 1)
            val rels = readRels(zip, dir + "_rels/" + fname + ".rels")

            val p = open(zip, info.path) ?: throw IllegalArgumentException("Sayfa verisi okunamadı.")

            val grid = TreeMap<Int, TreeMap<Int, String>>()
            val hyperRefs = ArrayList<Array<String?>>() // [ref, rid, location]
            val formulaLinks = ArrayList<Triple<Int, Int, String>>() // satır, sütun, adres

            var autoRow = 0
            var curRow = 0
            var lastCol = -1
            var curCol = 0
            var type: String? = null
            var style = -1
            val v = StringBuilder()
            val f = StringBuilder()
            val isT = StringBuilder()
            var inV = false
            var inF = false
            var inIs = false
            var inT = false
            var inRph = false

            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> {
                        when (ln(p)) {
                            "row" -> {
                                val r = attr(p, "r")?.toIntOrNull()
                                curRow = r ?: (autoRow + 1)
                                autoRow = curRow
                                lastCol = -1
                            }
                            "c" -> {
                                val ref = attr(p, "r")
                                if (ref != null) {
                                    val rc = parseRef(ref)
                                    if (rc.first > 0) curRow = rc.first
                                    curCol = rc.second
                                } else {
                                    curCol = lastCol + 1
                                }
                                lastCol = curCol
                                type = attr(p, "t")
                                style = attr(p, "s")?.toIntOrNull() ?: -1
                                v.setLength(0)
                                f.setLength(0)
                                isT.setLength(0)
                            }
                            "v" -> inV = true
                            "f" -> inF = true
                            "is" -> inIs = true
                            "rPh" -> inRph = true
                            "t" -> if (inIs) inT = !inRph
                            "hyperlink" -> hyperRefs.add(
                                arrayOf(attr(p, "ref"), attrSuffix(p, "id"), attr(p, "location"))
                            )
                        }
                    }
                    XmlPullParser.TEXT -> {
                        if (inV) v.append(p.text)
                        else if (inF) f.append(p.text)
                        else if (inT) isT.append(p.text)
                    }
                    XmlPullParser.END_TAG -> {
                        when (ln(p)) {
                            "v" -> inV = false
                            "f" -> inF = false
                            "is" -> inIs = false
                            "t" -> inT = false
                            "rPh" -> inRph = false
                            "c" -> {
                                val raw = v.toString()
                                val value: String = when (type) {
                                    "s" -> raw.trim().toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                                    "inlineStr" -> isT.toString()
                                    "b" -> if (raw.trim() == "1") "DOĞRU" else "YANLIŞ"
                                    "str", "e" -> raw
                                    else -> if (raw.isNotEmpty() && style >= 0 &&
                                        style < dateXf.size && dateXf[style]
                                    ) fmtDate(raw) else raw
                                }
                                if (f.isNotEmpty()) {
                                    val m = HYPERLINK_RE.find(f.toString())
                                    if (m != null) {
                                        formulaLinks.add(
                                            Triple(curRow, curCol, m.groupValues[1].replace("\"\"", "\""))
                                        )
                                    }
                                }
                                if (value.isNotEmpty() && curRow > 0) {
                                    grid.getOrPut(curRow) { TreeMap() }[curCol] = value
                                }
                            }
                        }
                    }
                }
                ev = p.next()
            }

            // --- köprüleri satır bazında topla
            val cellLinks = HashMap<Int, ArrayList<Triple<Int, Int, String>>>()
            fun addLink(r: Int, c: Int, target: String) {
                if (r <= 0 || target.isBlank()) return
                cellLinks.getOrPut(r) { ArrayList() }.add(Triple(r, c, target))
            }

            var guard = 0
            for (h in hyperRefs) {
                val ref = h[0] ?: continue
                val rid = h[1]
                val target = if (rid != null) rels[rid] else null
                if (target == null) continue // sayfa içi bağlantı (location) -> yok say
                val parts = ref.split(":")
                val a = parseRef(parts[0])
                val b = if (parts.size > 1) parseRef(parts[1]) else a
                for (r in a.first..b.first) {
                    for (c in a.second..b.second) {
                        if (guard++ > 50000) break
                        addLink(r, c, target)
                    }
                }
            }
            for (t in formulaLinks) addLink(t.first, t.second, t.third)

            // --- satırları oluştur
            val rowNumbers = TreeMap<Int, Boolean>()
            for (k in grid.keys) rowNumbers[k] = true
            for (k in cellLinks.keys) rowNumbers[k] = true

            val rows = ArrayList<Row>(rowNumbers.size)
            for (r in rowNumbers.keys) {
                val cellsMap = grid[r]
                val maxCol = if (cellsMap == null || cellsMap.isEmpty()) -1 else cellsMap.lastKey()
                val cells = ArrayList<String>(maxCol + 1)
                for (c in 0..maxCol) cells.add(cellsMap?.get(c) ?: "")

                val links = ArrayList<Link>()
                val seen = HashSet<String>()
                val lk = cellLinks[r]
                if (lk != null) {
                    lk.sortBy { it.second }
                    for (t in lk) {
                        if (!seen.add(t.third)) continue
                        val label = cellsMap?.get(t.second)?.takeIf { it.isNotBlank() } ?: lastSegment(t.third)
                        links.add(Link(label, t.third))
                    }
                }
                if (cells.any { it.isNotEmpty() } || links.isNotEmpty()) {
                    rows.add(Row(r, cells, links))
                }
            }
            rows
        }
    }

    // ---------------------------------------------------------------- yardımcılar

    private fun lastSegment(t: String): String {
        val s = t.trimEnd('/', '\\')
        val i = maxOf(s.lastIndexOf('/'), s.lastIndexOf('\\'))
        return if (i >= 0) s.substring(i + 1) else s
    }

    private fun open(zip: ZipFile, path: String): XmlPullParser? {
        val e = zip.getEntry(path) ?: return null
        val p = Xml.newPullParser()
        p.setInput(zip.getInputStream(e), null)
        return p
    }

    private fun ln(p: XmlPullParser): String {
        val n = p.name ?: return ""
        val i = n.indexOf(':')
        return if (i >= 0) n.substring(i + 1) else n
    }

    private fun attr(p: XmlPullParser, name: String): String? {
        for (i in 0 until p.attributeCount) {
            if (p.getAttributeName(i) == name) return p.getAttributeValue(i)
        }
        return null
    }

    private fun attrSuffix(p: XmlPullParser, name: String): String? {
        for (i in 0 until p.attributeCount) {
            val n = p.getAttributeName(i)
            if (n == name || n.endsWith(":$name")) return p.getAttributeValue(i)
        }
        return null
    }

    private fun readRels(zip: ZipFile, path: String): Map<String, String> {
        val p = open(zip, path) ?: return emptyMap()
        val m = HashMap<String, String>()
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && ln(p) == "Relationship") {
                val id = attr(p, "Id")
                val t = attr(p, "Target")
                if (id != null && t != null) m[id] = t
            }
            ev = p.next()
        }
        return m
    }

    private fun readShared(zip: ZipFile): List<String> {
        val p = open(zip, "xl/sharedStrings.xml") ?: return emptyList()
        val out = ArrayList<String>()
        var sb = StringBuilder()
        var inT = false
        var inRph = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    when (ln(p)) {
                        "si" -> sb = StringBuilder()
                        "rPh" -> inRph = true
                        "t" -> inT = !inRph
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inT) sb.append(p.text)
                }
                XmlPullParser.END_TAG -> {
                    when (ln(p)) {
                        "t" -> inT = false
                        "rPh" -> inRph = false
                        "si" -> out.add(sb.toString())
                    }
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun readDateStyles(zip: ZipFile): List<Boolean> {
        val p = open(zip, "xl/styles.xml") ?: return emptyList()
        val custom = HashMap<Int, String>()
        val result = ArrayList<Boolean>()
        var inXfs = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    when (ln(p)) {
                        "numFmt" -> {
                            val id = attr(p, "numFmtId")?.toIntOrNull()
                            val code = attr(p, "formatCode")
                            if (id != null && code != null) custom[id] = code
                        }
                        "cellXfs" -> inXfs = true
                        "xf" -> if (inXfs) {
                            val id = attr(p, "numFmtId")?.toIntOrNull() ?: 0
                            result.add(isDateFmt(id, custom[id]))
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (ln(p) == "cellXfs") inXfs = false
                }
            }
            ev = p.next()
        }
        return result
    }

    private fun isDateFmt(id: Int, code: String?): Boolean {
        if (id in 14..22 || id in 27..36 || id in 45..47 || id in 50..58) return true
        if (code == null) return false
        val sb = StringBuilder()
        var inQuote = false
        var inBracket = false
        for (ch in code) {
            when {
                ch == '"' -> inQuote = !inQuote
                inQuote -> {}
                ch == '[' -> inBracket = true
                ch == ']' -> inBracket = false
                inBracket -> {}
                else -> sb.append(ch)
            }
        }
        val s = sb.toString().lowercase(Locale.ROOT)
        if (s.contains("general")) return false
        return s.any { it == 'y' || it == 'd' || it == 'h' || it == 's' || it == 'm' }
    }

    private fun fmtDate(raw: String): String {
        val d = raw.trim().toDoubleOrNull() ?: return raw
        val days = Math.floor(d)
        val frac = d - days
        val secs = Math.round(frac * 86400.0)
        val time = String.format(Locale.ROOT, "%02d:%02d", secs / 3600, (secs % 3600) / 60)
        if (days < 1.0) return time
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.timeInMillis = Math.round((days - 25569.0) * 86400000.0)
        val date = String.format(
            Locale.ROOT, "%02d.%02d.%04d",
            cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.YEAR)
        )
        return if (frac > 0.00001) "$date $time" else date
    }

    /** "B12" -> (satır=12, sütun=1). Sütun 0 tabanlı. Çözülemezse (0,0). */
    private fun parseRef(ref: String): Pair<Int, Int> {
        var col = 0
        var i = 0
        while (i < ref.length && ref[i].isLetter()) {
            col = col * 26 + (ref[i].uppercaseChar() - 'A' + 1)
            i++
        }
        val row = ref.substring(i).toIntOrNull() ?: 0
        return Pair(row, col - 1)
    }
}
